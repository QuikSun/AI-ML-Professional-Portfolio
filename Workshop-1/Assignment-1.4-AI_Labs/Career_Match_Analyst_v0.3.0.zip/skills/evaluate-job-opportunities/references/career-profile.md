# User-specific profile and search review template

This reusable package intentionally contains no candidate's personal profile. Populate this review from information available for the current user only. Do not infer that the creator's experience, citizenship, preferences, or search limits apply to another person.

## Professional profile inputs
Include these fields in the first-input review, grouping related fields when useful:
- Professional background: roles, employers if supplied, employment dates, relevant non-overlapping experience, responsibilities, achievements, and supporting examples.
- Education: completed and in-progress credentials, field, enrollment status, expected graduation, and relevant credentials or licenses.
- Skills: tools, methods, languages, demonstrated proficiency for each, independent versus assisted work, and evidence. Separate general work experience from beginner technical skills. Explicitly record development areas and tasks the user wants to avoid, such as complex VBA or substantial coding, when supplied.
- Career direction: transferable strengths, desired transition, learning goals, responsibility level, individual-contributor or management preference.
- Availability: start date, weekly hours, daily schedule/time zone, internship dates/duration, enrollment constraints.
- Work authorization: country-specific user-reported work permission, employer sponsorship/support needs now or later, authorization categories and constraints only if relevant and supplied. Sensitive document identifiers are unnecessary.
- Source status: source/date where known, unresolved conflicts, unknown qualifications, and any prior context requiring reconfirmation.

## Target search inputs
- Mode: find openings, assess a supplied posting, or compare opportunities.
- Target titles, duties/job families, industries, seniority, management scope, and desired technical depth.
- Geography: countries, cities/regions, exact city versus metro boundary, relocation willingness, remote eligibility.
- Work arrangement: on-site/hybrid/remote, acceptable office attendance, travel.
- Employment types: permanent, fixed-term, contract, part-time, internship; priorities and exclusions.
- Schedule: minimum/maximum weekly hours, days, start date, season, duration; paid/unpaid acceptability.
- Compensation: currency, hourly/monthly/annual basis, minimum by employment type, flexibility, treatment of undisclosed pay.
- Commute: explicitly review the proposed maximum 10-minute walking route from the actual office entrance to the nearest usable public bus stop or rail/transit station; distinguish this from total commute time and home-side access. Also review mode, neighborhood/station if supplied, maximum each-way time, stretch tolerance, arrival/return times, car/driving constraints.
- Authorization filter: explicit incompatibilities to exclude, policy unknowns to retain/flag or exclude, internship/CPT requirements where relevant.
- Other hard requirements, preferences, employer/industry exclusions, realistic-stretch tolerance.
- Output: desired number (propose up to 20 if unspecified), tiered detail, fit rubric and any approved weight changes.
- Any additional assumption that would materially affect inclusion, ranking, feasibility or recommendations.

## Provenance and confirmation
Display two tables with columns **Field**, **Current value**, **Source/status**. Use User supplied; Prior user-specific context—please reconfirm; Proposed assumption/default; Unknown/TBD.
Never substitute Unknown with a guess. A current explicit correction supersedes older context, but include it in the confirmation review. Do not turn missing evidence into a confirmed weakness.
No salary, commute, nationality, location, authorization, seniority or skill-level default is silently active. The proposed output count and rubric are workflow settings, not personal facts.
After showing the review, ask for confirmation and wait. If the user changes material settings, display the changes and reconfirm before running recommendations.
A new user with no profile sees unknowns and is asked for essential background and target scope. A returning user sees their available user-specific inputs for reconfirmation. This package does not itself supply a database, identity system or persistent profile store.


