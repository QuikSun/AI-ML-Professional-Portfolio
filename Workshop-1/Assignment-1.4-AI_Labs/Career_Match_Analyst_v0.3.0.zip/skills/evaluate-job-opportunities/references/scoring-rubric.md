# Explained job fit rubric

Use this transparent comparison rubric, not a hiring probability or a validated selection instrument. Version 2: D/T/L/C/P replaces Education with Commute at the same 10-point weight. The total now combines professional match and office transit access; identify this when reporting scores. Keep other practical restrictions separate. Scores from the earlier D/T/L/E/P rubric are not directly comparable.

| Code | Criterion | Maximum points |
|---|---|---:|
| D | Duties and transferable professional experience | 40 |
| T | Required tools and technical depth | 25 |
| L | Responsibility level and scope | 15 |
| C | Commute: public-transit access to the actual office | 10 |
| P | Preferred qualifications and relevant domain knowledge | 10 |

For each criterion, use a rating from 0 to 4 and calculate points as maximum points multiplied by rating divided by four. Show the points and a short evidence-based explanation. Use 0 for a confirmed major mismatch, 1 for limited transferable evidence, 2 for a partial match with meaningful gaps, 3 for a good match with minor gaps, and 4 for a direct strong match. Rate a criterion U when a material fact needed for that assessment is unconfirmed; do not convert missing evidence into a claim of confirmed absence.

Education receives no points. Check legally or explicitly required degrees, licenses and credentials separately as eligibility requirements; do not use preferred education as a disguised education score under P. If no preferred requirement is stated, explain that no extra barrier was specified; do not invent desired credentials. Avoid counting the same accomplishment as multiple independent proofs of expertise.

With all criteria known, sum the five point values and round consistently to one decimal place. With U criteria, report a provisional score range: the lower bound is earned points from assessed criteria and the upper bound adds the unassessed criteria's maximum points. State exactly what information would narrow the range. Do not present the upper bound as a verified score or hide it in a confident category.

Categories for fully assessed fit are Strong match (80-100), Possible match (65-79.9), Realistic stretch (50-64.9), and Poor fit (below 50). Label a category provisional when unknowns cross a threshold. A confirmed essential credential or core-duty gap may justify Poor fit regardless of the arithmetic; explain the override. A hard practical conflict leads to Skip/excluded from shortlist even when skills fit is high.

For ranking, use assessed fit, the size of material unknowns, and practical feasibility together, stating any tradeoff. Do not penalize missing advertised salary in the professional-fit score. Maintain a separate practical status: No stated conflict identified, Needs confirmation, Commute stretch, or Excluded with reason. No stated conflict identified is not confirmation of legal eligibility.

For compact output, D/T/L/C/P means earned criterion points, such as 30/18.8/15/10/5, with maximums 40/25/15/10/10. Include a legend once. Keep the same scoring rubric across all roles in a comparison; if the user requests a weighting change, identify and version it before rescoring.


## C: office access by public transportation
The proposed office-access rule is a walking route of no more than 10 minutes between the actual office entrance and the nearest usable public bus stop or rail/transit station. Present this rule in the first-input review for each user and activate it after confirmation; the creator has explicitly requested it in this editing conversation. Do not hard-code the creator's home or profile.
- C = 10 (rating 4): verify the actual office entrance, usable stop/station, walking route at 10 minutes or less, and service at the required arrival/return times.
- C = U: office address, walking route/time, service, or required work schedule is not sufficiently established. Do not substitute a city center, guessed worksite, straight-line distance, or an invented route. State exactly what remains unknown.
- C = 0 (rating 0): verified nearest usable stop/station requires more than 10 minutes walking, or usable public transport is unavailable at required work times. When the user confirmed this as a hard limit, exclude the role from the regular shortlist regardless of total score.
- This is the office-side walk only. It does not establish the home-to-stop walk, total door-to-door time, transfers, or residential commute; check those separately if the user supplies requirements.
- For fully remote work with no mandatory office visits, C = 10 by convention (no required office commute), clearly labeled. Hybrid or occasional mandatory attendance still needs office verification. Multi-site roles need each mandatory site checked; flag unresolved field travel.
- Cite an official transit source or reliable route planner, record check date, and provide office address, stop/station, walking time and service evidence. Do not award points merely because a city is known for transit.

